<?php


/**
 * Includes
 * ----------------------------------------------------------------
 */

// config & functions
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/includes/Twig/Autoloader.php';
Twig_Autoloader::register();
$loader = new Twig_Loader_Filesystem(__DIR__ . '/templates');
$twig = new Twig_Environment($loader);


/**
 * Database Connection
 * ----------------------------------------------------------------
 */

$db = getDatabase();

// start session
session_start();
// user not set
if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = '';
}


//get topic id
$topicid = isset($_GET['topic']) ? (int)$_GET['topic'] : 0;
$items = array();


if ($topicid === 0) {
    // Get all task items from databases
    $stmt = $db->prepare('SELECT * FROM books ');
    $stmt->execute();
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {

// Get all task items by topicId
    $stmt = $db->prepare('SELECT * FROM books where topic_id LIKE ?');
    $stmt->execute(array($topicid));
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
//var_dump($items);


$userSet = array();


$stmt = $db->prepare('SELECT * FROM users');
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);


foreach ($users as $user) {
    $userSet[$user['id']] = $user['username'];
}
//var_dump($userSet);


$topicSet = array();


$stmt = $db->prepare('SELECT * FROM topics');
$stmt->execute();
$topics = $stmt->fetchAll(PDO::FETCH_ASSOC);


foreach ($topics as $topic) {
    $topicSet[$topic['id']] = $topic['title'];
}
//var_dump($topicSet);

/**
 * Load and render template
 * ----------------------------------------------------------------
 */
$tpl = $twig->loadTemplate('index.twig');
echo $tpl->render(array(
    'PHP_SELF' => $_SERVER['PHP_SELF'],
    'items' => $items,
    'users' => $userSet,
    'topics' => $topicSet,
    'user' => $_SESSION['user']
));



