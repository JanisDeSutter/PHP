<?php
/**
 * Includes
 * ----------------------------------------------------------------
 */

// config & functions
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/includes/Twig/Autoloader.php';
Twig_Autoloader::register();
$loader = new Twig_Loader_Filesystem(__DIR__ . '/templates');
$twig = new Twig_Environment($loader);
$formErrors = array();

/**
 * Database Connection
 * ----------------------------------------------------------------
 */

$db = getDatabase();

session_start();


//var_dump($_SESSION['user']);

// Get all books from databases
$stmt = $db->prepare('SELECT * FROM books ');
$stmt->execute();
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
$last = end($books);
$lastID = (int)$last['id'];
$next = $lastID + 1;


$title = isset($_POST['title']) ? $_POST['title'] : '';
$numpages = isset($_POST['numpages']) ? $_POST['numpages'] : '';
$topic_id = isset($_POST['topic_id']) ? $_POST['topic_id'] : '';
$userId = $_SESSION['user']['id'];

if (isset($_POST['moduleAction']) && ($_POST['moduleAction'] == 'add')) {

    // Check form: what not filled in
    if (trim($title) === '') {
        $formErrors[] = 'enter a title';
    }
    // Check form: what not filled in
    if (trim($numpages) === '') {
        $formErrors[] = 'enter the amount of pages';
    }

    // Check form: what not filled in
    if ($topic_id === '0') {
        $formErrors[] = 'give a topic';
    }


    if (isset($_FILES['coverphoto']) && sizeof($formErrors) == 0) {

        $file = new SplFileInfo($_FILES['coverphoto']['name']);
        $extension = ($file)->getExtension();


        // check file extension
        if (!in_array($extension, array('jpeg', 'jpg', 'png', 'gif'))) {
            $formErrors[] = 'this extionsion in not allowed please select a file with jpeg\', \'jpg\', \'png\' or \'gif\' as extension';
        } else {

            // file in folder steken
            @move_uploaded_file(
                $_FILES['coverphoto']['tmp_name'],
                __DIR__ . DIRECTORY_SEPARATOR . 'files/covers' . DIRECTORY_SEPARATOR . $next . '.' . $extension
            ) or die($formErrors[] = 'error uploading coverphoto');


            // build & execute prepared statement
            $stmt = $db->prepare('INSERT INTO books (title, numpages, user_id, topic_id,cover_extension,added_on) VALUES (?, ?, ?, ?,?,?)');
            $stmt->execute(array($title, $numpages, $userId, $topic_id, $extension, (new DateTime())->format('Y-m-d H:i:s')));


        }


    }


}

/**
 * Load and render template
 * ----------------------------------------------------------------
 */
$tpl = $twig->loadTemplate('add.twig');
echo $tpl->render(array(
    'action' => $_SERVER['PHP_SELF'],
    'errors' => $formErrors
));

