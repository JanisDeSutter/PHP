<?php
/**
 * Includes
 * ----------------------------------------------------------------
 */

// config & functions
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/includes/Twig/Autoloader.php';
Twig_Autoloader::register();
$loader = new Twig_Loader_Filesystem(__DIR__ . '/templates');
$twig = new Twig_Environment($loader);

/**
 * Database Connection
 * ----------------------------------------------------------------
 */

$db = getDatabase();
// start session
session_start();

// als user niet ingestelt is stel een lege in
if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = '';
}


//get the topic id
$topicId = isset($_GET['topic']) ? (int)$_GET['topic'] : 0;
//var_dump($topicId);
$items = [];

//get items from topicid
if ((int)$topicId === 0) {

    $stmt = $db->prepare('SELECT * FROM books');
    $stmt->execute();
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $db->prepare('SELECT * FROM books WHERE topic_id LIKE ?');
    $stmt->execute(array((int)$topicId));
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

}

//var_dump($items);
$userSet = [];
$topicSet = [];

//create userset
$stmt = $db->prepare('SELECT * FROM users');
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($users as $user) {
    $userSet[$user['id']] = $user['username'];
}
/*************************************/
//create topic set
$stmt = $db->prepare('SELECT * FROM topics');
$stmt->execute();
$topics = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($topics as $topic) {
    $topicSet[$topic['id']] = $topic['title'];
}

$tpl = $twig->loadTemplate('index.twig');
echo $tpl->render(array(
    'PHP_SELF' => $_SERVER['PHP_SELF'],
    'items' => $items,
    'users' => $userSet,
    'topics' => $topicSet,
    'user' => $_SESSION['user']
));
























