<?php
session_start();

/**
 * Includes
 * ----------------------------------------------------------------
 */

// config & functions
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/includes/Twig/Autoloader.php';
Twig_Autoloader::register();
$loader = new Twig_Loader_Filesystem(__DIR__ . '/templates');
$twig = new Twig_Environment($loader);

$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$password = isset($_POST['password']) ? trim($_POST['password']) : '';
$formErrors = [] ;

/**
 * Database Connection
 * ----------------------------------------------------------------
 */

$db = getDatabase();


if (isset($_POST['moduleAction']) && ($_POST['moduleAction'] == 'login')) {
   // var_dump($_POST);


    // Get user with sent in username from DB
    $stmt = $db->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute(array($username));


    // No user found
    if ($stmt->rowCount() != 1) {
        $formErrors[] = 'Ongeldige login-gegevens';
        var_dump($formErrors);
    } // User found

    else {

        // Fetch user
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        // Password checks out
        if (password_verify($password, $user['password'])) { //checkt het hashed password


            //stelt data van de sessie in
            $_SESSION['user'] = $user;


            // username to cookie
            setcookie('username', $user['username'], time() + 60 * 60 * 24 * 7);
            setcookie('datum', $datum, (new DateTime())->format('Y-m-d H:i:s'));


            // naar index.php
            header('location: index.php');

            exit();
        } else { //als het niet juist is

            $formErrors[] = 'Ongeldige login-gegevens'; //push een errors in $formErrors

        }
    }




}

$tpl = $twig->loadTemplate('login.twig');
echo $tpl->render(array(
    'action' => $_SERVER['PHP_SELF'],
    'errors' => $formErrors,
));


