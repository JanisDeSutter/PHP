<?php


/**
 * Includes
 * ----------------------------------------------------------------
 */

// config & functions
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/includes/Twig/Autoloader.php';
Twig_Autoloader::register();
$loader = new Twig_Loader_Filesystem(__DIR__ . '/templates');
$twig = new Twig_Environment($loader);
/**
 * Database Connection
 * ----------------------------------------------------------------
 */

$db = getDatabase();


/**
 * Session Control: Only allow logged in users to this site
 * ----------------------------------------------------------------
 */

// start session
session_start();
//var_dump($_POST);

$stmt = $db->prepare('SELECT * FROM books ');
$stmt->execute();
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
//var_dump($books);
$l = end($books);
$lastId = (int)$l['id'];
$next = $lastId + 1;
//var_dump($next);


$title = isset($_POST['title']) ? $_POST['title'] : '';
$numpages = isset($_POST['numpages']) ? $_POST['numpages'] : '';
$topic_id = isset($_POST['topic_id']) ? $_POST['topic_id'] : '';
$formErrors = array();

$user = $_SESSION['user']['id'];
//var_dump($user);

if (isset($_POST['moduleAction']) && ($_POST['moduleAction'] == 'add')) {

    if (trim($title) === '') {
        $formErrors[] = 'Voer een geldige title in';
    }
    if (trim($numpages) === '') {
        $formErrors[] = 'Voer een geldig aantal paginas in';
    }
    if (trim($topic_id) === '0') {
        $formErrors[] = 'Voer een geldig topic_id  in';
    }
    if (trim($_FILES['coverphoto']['name']) === '') {
        $formErrors[] = 'gelieve een bestand te selecteren';
    }

    $file = new SplFileInfo($_FILES['coverphoto']['name']);
    $extension = $file->getExtension();

    if (!in_array(($extension), array('jpeg', 'jpg', 'png', 'gif'))) {
        $formErrors[] = 'gelieve een file te selecteren met een juiste extension';
    }


    if (sizeof($formErrors) === 0) {

        //upload
        // file in folder steken
        @move_uploaded_file(
            $_FILES['coverphoto']['tmp_name'],
            __DIR__ . DIRECTORY_SEPARATOR . 'files/covers' . DIRECTORY_SEPARATOR . $next . '.' . $extension
        ) or die($formErrors[] = 'failed uploading image to folder');


        //insert
        if (sizeof($formErrors) === 0) {
            // build & execute prepared statement
            $stmt = $db->prepare('INSERT INTO books (title, numpages, user_id, topic_id,cover_extension,added_on) VALUES (?, ?, ?, ?,?,?)');
            $stmt->execute(array($title, $numpages, $user, $topic_id, $extension, (new DateTime())->format('Y-m-d H:i:s')));
        }


    }


}

/**
 * Load and render template
 * ----------------------------------------------------------------
 */


$tpl = $twig->loadTemplate('add.twig');

echo $tpl->render(array(
    'action' => $_SERVER['PHP_SELF'],
    'errors' => $formErrors,
    'title' => $title,
    'numpages' => $numpages,

));



