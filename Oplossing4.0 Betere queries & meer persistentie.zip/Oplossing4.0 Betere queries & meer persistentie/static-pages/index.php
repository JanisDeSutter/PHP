<?php


/**
 * Includes
 * ----------------------------------------------------------------
 */

// config & functions
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/includes/Twig/Autoloader.php';
Twig_Autoloader::register();
$loader = new Twig_Loader_Filesystem(__DIR__ . '/templates');
$twig = new Twig_Environment($loader);
/**
 * Database Connection
 * ----------------------------------------------------------------
 */

$db = getDatabase();


/**
 * Session Control: Only allow logged in users to this site
 * ----------------------------------------------------------------
 */

// start session
session_start();

if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = '';
}

//var_dump($_SESSION['user']);


//get the topic id
$topicId = isset($_GET['topic']) ? (int)$_GET['topic'] : 0;

if ($topicId == 0) {
    $stmt = $db->prepare('SELECT books.id AS bookId, books.title AS bookTitle, books.numpages AS numpages, 
    books.topic_id AS topic_id, books.cover_extension AS extension, users.username AS userName, 
topics.title AS topicName FROM `books` INNER JOIN topics ON topics.id = books.topic_id 
INNER JOIN users ON books.user_id = users.id ORDER BY books.title ');
    $stmt->execute();
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $db->prepare('SELECT books.id AS bookId, books.title AS bookTitle, books.numpages AS numpages, 
books.topic_id AS topic_id, books.cover_extension AS extension, users.username AS userName, 
topics.title AS topicName FROM `books` INNER JOIN topics ON topics.id = books.topic_id 
INNER JOIN users ON books.user_id = users.id WHERE books.topic_id LIKE ? ORDER BY books.title');
    $stmt->execute(array($topicId));
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

}
//var_dump($items);

/**
 * Load and render template
 * ----------------------------------------------------------------
 */
$tpl = $twig->loadTemplate('index.twig');
echo $tpl->render(array(
    'PHP_SELF' => $_SERVER['PHP_SELF'],
    'items' => $items,
    'user' => $_SESSION['user']
));



